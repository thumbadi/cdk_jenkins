package com.example.awssqsdemo;

public class MessageContent {
    private String record_id;
    private int sequence_no;
    private String mtf_responsecode;
    private String adj_deletioncode;
    private String date_of_service;
    private long pres_serviceref_no;
    private int fill_number;
    private String service_providerId_qual;
    private String service_provider_id;
    private String alter_service_provid_qual;
    private String alter_service_provid_id;
    private String prescriberId_qual;
    private String prescriber_id;
    private String filler_1;
    private String product_service_id;
    private String qty_dispensed;
    private int days_supply;
    private String indicator;
    private String filler_2;
    private String orgi_submit_cont;
    private String claim_control_no;
    private String card_holder_id;
	public String getRecord_id() {
		return record_id;
	}
	public void setRecord_id(String record_id) {
		this.record_id = record_id;
	}
	public int getSequence_no() {
		return sequence_no;
	}
	public void setSequence_no(int sequence_no) {
		this.sequence_no = sequence_no;
	}
	public String getMtf_responsecode() {
		return mtf_responsecode;
	}
	public void setMtf_responsecode(String mtf_responsecode) {
		this.mtf_responsecode = mtf_responsecode;
	}
	public String getAdj_deletioncode() {
		return adj_deletioncode;
	}
	public void setAdj_deletioncode(String adj_deletioncode) {
		this.adj_deletioncode = adj_deletioncode;
	}
	public String getDate_of_service() {
		return date_of_service;
	}
	public void setDate_of_service(String date_of_service) {
		this.date_of_service = date_of_service;
	}
	public long getPres_serviceref_no() {
		return pres_serviceref_no;
	}
	public void setPres_serviceref_no(long pres_serviceref_no) {
		this.pres_serviceref_no = pres_serviceref_no;
	}
	public int getFill_number() {
		return fill_number;
	}
	public void setFill_number(int fill_number) {
		this.fill_number = fill_number;
	}
	public String getService_providerId_qual() {
		return service_providerId_qual;
	}
	public void setService_providerId_qual(String service_providerId_qual) {
		this.service_providerId_qual = service_providerId_qual;
	}
	public String getService_provider_id() {
		return service_provider_id;
	}
	public void setService_provider_id(String service_provider_id) {
		this.service_provider_id = service_provider_id;
	}
	public String getAlter_service_provid_qual() {
		return alter_service_provid_qual;
	}
	public void setAlter_service_provid_qual(String alter_service_provid_qual) {
		this.alter_service_provid_qual = alter_service_provid_qual;
	}
	public String getAlter_service_provid_id() {
		return alter_service_provid_id;
	}
	public void setAlter_service_provid_id(String alter_service_provid_id) {
		this.alter_service_provid_id = alter_service_provid_id;
	}
	public String getPrescriberId_qual() {
		return prescriberId_qual;
	}
	public void setPrescriberId_qual(String prescriberId_qual) {
		this.prescriberId_qual = prescriberId_qual;
	}
	public String getPrescriber_id() {
		return prescriber_id;
	}
	public void setPrescriber_id(String prescriber_id) {
		this.prescriber_id = prescriber_id;
	}
	public String getFiller_1() {
		return filler_1;
	}
	public void setFiller_1(String filler_1) {
		this.filler_1 = filler_1;
	}
	public String getProduct_service_id() {
		return product_service_id;
	}
	public void setProduct_service_id(String product_service_id) {
		this.product_service_id = product_service_id;
	}
	public String getQty_dispensed() {
		return qty_dispensed;
	}
	public void setQty_dispensed(String qty_dispensed) {
		this.qty_dispensed = qty_dispensed;
	}
	public int getDays_supply() {
		return days_supply;
	}
	public void setDays_supply(int days_supply) {
		this.days_supply = days_supply;
	}
	public String getIndicator() {
		return indicator;
	}
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	public String getFiller_2() {
		return filler_2;
	}
	public void setFiller_2(String filler_2) {
		this.filler_2 = filler_2;
	}
	public String getOrgi_submit_cont() {
		return orgi_submit_cont;
	}
	public void setOrgi_submit_cont(String orgi_submit_cont) {
		this.orgi_submit_cont = orgi_submit_cont;
	}
	public String getClaim_control_no() {
		return claim_control_no;
	}
	public void setClaim_control_no(String claim_control_no) {
		this.claim_control_no = claim_control_no;
	}
	public String getCard_holder_id() {
		return card_holder_id;
	}
	public void setCard_holder_id(String card_holder_id) {
		this.card_holder_id = card_holder_id;
	}

    // Getters & Setters
    
    
}
