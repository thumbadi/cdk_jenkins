package com.example.awssqsdemo;

public class MessageData {
    private String messageId;  // SQS-generated messageId
    private MessageContent content;

    public MessageData(String messageId, MessageContent content) {
        this.messageId = messageId;
        this.content = content;
    }

    public String getMessageId() {
        return messageId;
    }

    public MessageContent getContent() {
        return content;
    }
}
