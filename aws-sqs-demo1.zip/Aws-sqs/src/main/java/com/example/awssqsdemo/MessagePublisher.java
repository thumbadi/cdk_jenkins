//package com.example.awssqsdemo;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//import software.amazon.awssdk.services.sqs.SqsClient;
//import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
//
//import java.time.Instant;
//import java.util.UUID;
//
//@Component
//public class MessagePublisher implements CommandLineRunner {
//    
//    private final SqsClient sqsClient;
//    private final ObjectMapper objectMapper;
//    
//    @Value("${aws.sqs.queueUrl}")
//    private String queueUrl;
//    
//    public MessagePublisher(SqsClient sqsClient, ObjectMapper objectMapper) {
//        this.sqsClient = sqsClient;
//        this.objectMapper = objectMapper;
//    }
//    
//    @Override
//    public void run(String... args) throws Exception {
//        // Publish some test messages
//        for (int i = 1; i <= 5; i++) {
//            Message message = new Message();
//            message.setId(UUID.randomUUID().toString());
//            message.setContent("Test message " + i);
//            message.setTimestamp(Instant.now().toString());
//            
//            String messageBody = objectMapper.writeValueAsString(message);
//            
//            SendMessageRequest sendRequest = SendMessageRequest.builder()
//                    .queueUrl(queueUrl)
//                    .messageBody(messageBody)
//                    .build();
//            
//            sqsClient.sendMessage(sendRequest);
//        }
//    }
//}