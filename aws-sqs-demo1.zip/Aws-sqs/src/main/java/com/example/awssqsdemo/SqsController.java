package com.example.awssqsdemo;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
public class SqsController {
    
    private final SqsService sqsService;
    
    public SqsController(SqsService sqsService) {
        this.sqsService = sqsService;
    }
    
    @GetMapping("/getallmessages")
    public ResponseEntity<List<String>> getAllMessages() {
        return ResponseEntity.ok(sqsService.getAllMessages());
    }
    
    @GetMapping("/getbyid/{id}")
    public ResponseEntity<MessageData> getMessageById(@PathVariable String id) {
        MessageData message = sqsService.getMessageById(id);
        if (message == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(message);
    }
}
