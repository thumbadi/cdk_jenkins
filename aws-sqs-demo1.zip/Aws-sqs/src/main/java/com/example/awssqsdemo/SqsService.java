//package com.example.awssqsdemo;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//import software.amazon.awssdk.services.sqs.SqsClient;
//import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
//import software.amazon.awssdk.services.sqs.model.ReceiveMessageResponse;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//@Service
//public class SqsService {
//    
//    private final SqsClient sqsClient;
//    private final ObjectMapper objectMapper;
//    private final Map<String, Message> messageCache = new HashMap<>();
//    
//    @Value("${aws.sqs.queueUrl}")
//    private String queueUrl;
//    
//    public SqsService(SqsClient sqsClient, ObjectMapper objectMapper) {
//        this.sqsClient = sqsClient;
//        this.objectMapper = objectMapper;
//    }
//    
//    public List<Message> getAllMessages() {
//        ReceiveMessageRequest receiveRequest = ReceiveMessageRequest.builder()
//                .queueUrl(queueUrl)
//                .maxNumberOfMessages(10)
//                .build();
//        
//        ReceiveMessageResponse response = sqsClient.receiveMessage(receiveRequest);
//        List<Message> messages = new ArrayList<>();
//        
//        response.messages().forEach(message -> {
//            try {
//                Message msg = objectMapper.readValue(message.body(), Message.class);
//                messageCache.put(msg.getId(), msg);
//                messages.add(msg);
//            } catch (JsonProcessingException e) {
//                throw new RuntimeException("Error processing message", e);
//            }
//        });
//        
//        return messages;
//    }
//    
//    public Message getMessageById(String id) {
//        return messageCache.get(id);
//    }
//}


package com.example.awssqsdemo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageResponse;
import software.amazon.awssdk.services.sqs.model.Message;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SqsService {
    
    private final SqsClient sqsClient;
    private final ObjectMapper objectMapper;
    private final Map<String, MessageData> messageCache = new HashMap<>();
    
    @Value("${aws.sqs.queueUrl}")
    private String queueUrl;
    
    public SqsService(SqsClient sqsClient, ObjectMapper objectMapper) {
        this.sqsClient = sqsClient;
        this.objectMapper = objectMapper;
    }
    
    public List<String> getAllMessages() {
        ReceiveMessageRequest receiveRequest = ReceiveMessageRequest.builder()
                .queueUrl(queueUrl)
                .maxNumberOfMessages(10)
                .build();
        
        ReceiveMessageResponse response = sqsClient.receiveMessage(receiveRequest);
        List<String> messages = new ArrayList<>();
        
        for (Message message : response.messages()) {
            try {
                MessageContent msgContent = objectMapper.readValue(message.body(), MessageContent.class);
                MessageData msgData = new MessageData(message.messageId(), msgContent);

                // Store in cache using SQS-generated message ID
                messageCache.put(msgData.getMessageId(), msgData);
                messages.add(msgData.getMessageId());
            } catch (JsonProcessingException e) {
                throw new RuntimeException("Error processing message", e);
            }
        }
        
        return messages;
    }
    
    public MessageData getMessageById(String id) {
        return messageCache.get(id);
    }
}

