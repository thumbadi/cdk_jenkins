package com.myorg;
import com.myorg.conf;
import software.constructs.Construct;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.*;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.services.s3.*;
import software.amazon.awscdk.services.sagemaker.*;
import software.amazon.awscdk.services.iam.*;
import java.util.*;

// import software.amazon.awscdk.Duration;
// import software.amazon.awscdk.services.sqs.Queue;

public class CdkJavaStack extends Stack {
    public CdkJavaStack(final Construct scope, final String id) {
        this(scope, id, null);
    }

    public CdkJavaStack(final Construct scope, final String id, final StackProps props) {
        super(scope, id, props);
        
        conf cf = new conf();
        int count = 0;
        ArrayList<HashMap<String,Object>> groups = cf.groupsList();
        ArrayList<HashMap<String,Object>> roles  = cf.rolesList();
        
        
        ArrayList<CfnGroup> cfngroups  = new ArrayList<CfnGroup>();
        ArrayList<CfnUser> cfnusers  = new ArrayList<CfnUser>();
        
        
        //System.out.print(groups);
        
        /*Bucket bucket = Bucket.Builder.create(this, "S3Bucket")
                                      .bucketName(cf.s3_bucket)
                                      .build();*/
        
        
        for ( int r = 0 ; r < roles.size() ; r++){
            
            HashMap<String,Object> iamrole = roles.get(r);
            HashMap<String,Object> saverole = new HashMap<String,Object>();
            List<String> actions = (List<String>) iamrole.get("actions");
            
            Role role = Role.Builder.create(this,(String)iamrole.get("rolename"))
                    .roleName((String)iamrole.get("rolename"))
                    .assumedBy(new ServicePrincipal((String)iamrole.get("principal")))
                    .build();
                    
            role.addToPolicy(PolicyStatement.Builder.create()
                             .effect(Effect.ALLOW)
                             .actions(actions)
                             .resources(List.of("*"))
                             .build()
            );
            
            
            List<String> managed = (List<String>)iamrole.get("managed");
            
            for ( int i = 0 ; i < managed.size() ; i++ ){
              role.addManagedPolicy(ManagedPolicy.fromAwsManagedPolicyName(managed.get(i)));
            }
            
            
            
        }
        
        // create groups
        for (int i = 0 ;  i < groups.size() ; i++){
            
            HashMap<String,Object> iamgroup = groups.get(i);
            String groupname = (String)groups.get(i).get("groupname");
            List<String> actions =  (List<String>)groups.get(i).get("actions");  
            
            CfnGroup cfngroup = CfnGroup.Builder.create(this,groupname)
                                           .groupName(groupname)
                                           .build();
                                           
            
            PolicyDocument  policy = PolicyDocument.Builder.create()
                                                 .statements(List.of(PolicyStatement.Builder.create()
                                                 .actions(actions)
                                                 .resources(List.of("*"))
                                                 .build()))
                                                 .build();
                                                 
            CfnGroup.PolicyProperty policyproperty = CfnGroup.PolicyProperty.builder()
                                 .policyDocument(policy)
                                 .policyName("policy"+groupname)
                                 .build();
                                 
                                 
            if(iamgroup.containsKey("managedpolicies")){
                List<String> managedpolicies = (List<String>)iamgroup.get("managedpolicies");
                cfngroup.setManagedPolicyArns(managedpolicies);
            }                     
               
            
            if (iamgroup.containsKey("roles")){
                
                List<String> grouprole = (List<String>) iamgroup.get("roles");
                List<String> arns = new ArrayList<String>();
                
                for(int j = 0 ; j < grouprole.size() ; j++){
                    arns.add("arn:aws:iam::"+cf.accountid+":role/"+grouprole.get(j));
                }
                
                PolicyDocument group_assumerole = PolicyDocument.Builder.create()
                                                 .statements(List.of(PolicyStatement.Builder.create()
                                                 .effect(Effect.ALLOW)
                                                 .actions(List.of("sts:AssumeRole"))
                                                 .resources(arns)
                                                 .build()))
                                                 .build();
                                                 
                CfnGroup.PolicyProperty assumerolepolicy = CfnGroup.PolicyProperty.builder()
                                 .policyDocument(group_assumerole)
                                 .policyName("assumerolegroup")
                                 .build();
                                 
                cfngroup.setPolicies(List.of(policyproperty, assumerolepolicy));
            }else{
                
                cfngroup.setPolicies(List.of(policyproperty));
                //System.out.print("hi");
            }
                                     
            
            //cfngroup.setPolicies(List.of(policyproperty));                               
            cfngroups.add(cfngroup);           
            
        }
        
        // create users
        List<String> users  = cf.users;
        for (int j = 0 ; j < users.size() ; j++){
            String user = users.get(j);
            CfnUser cfnuser = CfnUser.Builder.create(this, user)
                                                .userName(user)
                                                .build();
                                                
            cfnusers.add(cfnuser);
            
            count++;
        }
        
        // attach users and groups
        for(int g = 0 ; g < groups.size() ; g++){
            
            String groupname = (String)groups.get(g).get("groupname");
            List<String> usersgroup = (List<String>)groups.get(g).get("users");
            
            
            CfnUserToGroupAddition cfnUserToGroupAddition = CfnUserToGroupAddition.Builder.create(this, "MyCfnUserToGroupAddition"+groupname)
                                                                                         .groupName(groupname)
                                                                                         .users(usersgroup)
                                                                                      .build();
            cfnUserToGroupAddition.addDependsOn(cfngroups.get(g));
            
            for (int u = 0 ; u < usersgroup.size() ; u++){
                cfnUserToGroupAddition.addDependsOn(cfnusers.get(u));
            }
            
            
        }
        
        
    }
}
