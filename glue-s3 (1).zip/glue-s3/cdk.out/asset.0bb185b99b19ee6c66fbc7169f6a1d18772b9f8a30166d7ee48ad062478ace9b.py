import sys
import boto3
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.job import Job

# Parse the input arguments
args = getResolvedOptions(sys.argv, ['DestinationBucketName', 'SourceBucketName', 'ObjectKey', 'FileName'])

# Create GlueContext and SparkContext
glueContext = GlueContext(SparkContext.getOrCreate())
job = Job(glueContext)

# Load the data from the Glue catalog

dynamicframe = glueContext.create_dynamic_frame.from_catalog(
    database="sampledb",
    table_name=args['FileName']
)

# Write the transformed data to the destination bucket in ORC format
datasink4 = glueContext.write_dynamic_frame.from_options(
    frame=dynamicframe,
    connection_type="s3",
    connection_options={"path": "s3://" + args['DestinationBucketName'] + "/" + args['ObjectKey']},
    format="csv",
    format_options={"quoteChar": '"', "separator": ","},  # Optional: to specify CSV options
    transformation_ctx="datasink4"
)

# Initialize a boto3 S3 client
s3_client = boto3.client('s3')

# Delete the file from the source bucket
s3_client.delete_object(Bucket=args['SourceBucketName'], Key=args['ObjectKey'])

# Commit the Glue job
job.commit()
