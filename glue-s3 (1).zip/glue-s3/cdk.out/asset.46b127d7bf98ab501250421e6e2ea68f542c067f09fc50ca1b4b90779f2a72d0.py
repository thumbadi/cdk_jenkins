import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.job import Job

args = getResolvedOptions(sys.argv, ['DestinationBucketName', 'FileName']) 

glueContext = GlueContext(SparkContext.getOrCreate())
job = Job(glueContext)

column_name_dynamicframe = glueContext.create_dynamic_frame.from_catalog(
       database = "sampledb",
       table_name = args['FileName']+'namefile')

userdata_dynamicframe = glueContext.create_dynamic_frame.from_catalog(
       database = "sampledb",
       table_name = args['FileName'])

#Generate the applymapping script dynamically and apply it #on our dynamicframe data file
	
mapping = []
for x in range(0, len(userdata_dynamicframe.schema().fields)) :
    mapping.append((
	userdata_dynamicframe.schema().fields[x].name,
	column_name_dynamicframe.schema().fields[x].name
    ))		
userdata_dynamicframe = userdata_dynamicframe.apply_mapping(mapping)



datasink4 = glueContext.write_dynamic_frame.from_options(
	frame = userdata_dynamicframe, 
	connection_type = "s3", 
	connection_options = {"path": "s3://"+args['DestinationBucketName']			+"/"+args['FileName']+'/'+args['FileName']+'FileRenamed'}, 
	format = "orc", 
	transformation_ctx = "datasink4"
)
job.commit()