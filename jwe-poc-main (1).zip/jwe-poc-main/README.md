# jwe-poc

JWT -> JWS -> JWE -> validated JWS

To run the test use:

```
./mvnw clean test
```

Tested with Java 17.0.6.
