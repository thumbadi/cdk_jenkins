package com.example.controller;

import java.io.IOException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;

@RestController
@RequestMapping("/api")
public class TokenCheckController {

    public static final String publicKey = // "-----BEGIN PUBLIC KEY-----" +
            "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAt/ROS+dt1iB0p0tDoVvH" + //
                    "QMNL9EOJU9mqoFYGZh1YuySjtZggRBks5m2ZN73URnWnsL+XiuZdp5s5ZaUbmGGE" + //
                    "sd9BglaeI2BbqdpayONvEJ7l1lsD+wVc5dTnBYXZ83oguQAXLpskogvahKbv4Wjt" + //
                    "Clu7fxdoHLzmQm6bD0kpnHTkor/JBFfyHIhPI8NsFBejOcz4/4DbBKysJZbEU7Uo" + //
                    "dQQiJywb4g+Jm0UG3FGSZgK3GFKDq2DINUw56E7pR3tNax5bBhDbIT6a0tXT5mPK" + //
                    "/JuIHen0admRDQYJ2jVyFrHTr4SUT7TL/18D9btx632qDt2xcqtqJvtQZDUKRLuj" + //
                    "DQIDAQAB";// + "-----END PUBLIC KEY-----";

    private String mesString = "";

    public Boolean isValidToken(String token) {
        try {
            buildJWTVerifier().verify(token.replace("Bearer ", ""));
            // if token is valid no exception will be thrown
            System.out.println("Valid TOKEN");
            return Boolean.TRUE;
        } catch (CertificateException e) {
            // if CertificateException comes from buildJWTVerifier()
            System.out.println("InValid TOKEN");
            e.printStackTrace();
            return Boolean.FALSE;
        } catch (JWTVerificationException e) {
            // if JWT Token in invalid
            System.out.println("InValid TOKEN");
            e.printStackTrace();
            return Boolean.FALSE;
        } catch (IOException e) {
            // if JWT Token in invalid
            System.out.println("InValid TOKEN");
            e.printStackTrace();
            return Boolean.FALSE;
        } catch (Exception e) {
            // If any other exception comes
            System.out.println("InValid TOKEN, Exception Occurred");
            e.printStackTrace();
            return Boolean.FALSE;
        }
    }

    private JWTVerifier buildJWTVerifier() throws CertificateException, IllegalArgumentException, IOException,
            NoSuchAlgorithmException, InvalidKeySpecException {
        var algo = Algorithm.RSA256(getRSAPublicKey(), null);
        return JWT.require(algo).build();
    }

    private RSAPublicKey getRSAPublicKey()
            throws CertificateException, IOException, NoSuchAlgorithmException, InvalidKeySpecException {

        // System.out.println("before decoded PublicKey==>>" + publicKey);

        byte[] encoded = Base64.decodeBase64(publicKey);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        RSAPublicKey publicKey = (RSAPublicKey) kf.generatePublic(new X509EncodedKeySpec(encoded));

        System.out.println("RSAPublicKey" + publicKey);
        return publicKey;

    }

    @GetMapping(value = "/tokenCheck")
    public ResponseEntity<String> checkToken(@RequestHeader("Authorization") String tokenString) {

        System.out.println(tokenString);

        // byte[] decode = Base64.getDecoder().decode(publicKey);
        // String decodedString = new String(decode);
        // System.out.println("tokenCheck decoded PublicKey==>>" + decodedString);

        Boolean checked = isValidToken(tokenString);

        if (checked) {
            String jwtToken = tokenString.replace("Bearer ", "");

            System.out.println("------------ Decode JWT ------------");
            String[] split_string = jwtToken.split("\\.");
            String base64EncodedHeader = split_string[0];
            String base64EncodedBody = split_string[1];
            String base64EncodedSignature = split_string[2];

            System.out.println("~~~~~~~~~ JWT Header ~~~~~~~");
            Base64 base64Url = new Base64(true);
            String header = new String(base64Url.decode(base64EncodedHeader));
            System.out.println("JWT Header : " + header);

            System.out.println("~~~~~~~~~ JWT Body ~~~~~~~");
            String body = new String(base64Url.decode(base64EncodedBody));
            System.out.println("JWT Body : " + body);

            JSONObject jo = new JSONObject(body);
            System.out.println("~~~~~~~~~ JWT Object ~~~~~~~");
            System.out.println("JWT Role : " + jo.optString("Role"));
            System.out.println("JWT app_displayname : " + jo.optString("app_displayname"));
            if (!jo.optString("Role").equals("Admin") || !jo.optString("app_displayname").equals("SMBDomainService")) {
                checked = Boolean.FALSE;
                System.out.println("Here");
            }
        }

        return ResponseEntity.ok(checked.toString());
    }

}
